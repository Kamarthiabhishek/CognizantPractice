package com.cts.ekart;

import java.util.Scanner;
import com.cts.service.UserFunctions;

public class App {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		boolean b = true;
		while (b) {
			System.out.println("WELCOME TO VASH E-KART ");
			int flag1 = 0;
			while (flag1 == 0) {
				System.out.println("1. ADMIN\n" + "2. CUSTOMER\n");
				System.out.print("Enter your choice : ");
				char ch1 = sc.next().charAt(0);
				switch (ch1) {
				case '1':
					int i = 0;
					do {
						System.out.println("1. REGISTER\n" + "2. LOGIN\n");
						System.out.println("Enter your choice : ");
						char ch2 = sc.next().charAt(0);
						switch (ch2) {
						case '1':
							UserFunctions.Details(1);
							i++;
						case '2':
							boolean fncs = true;
							while (fncs) {
								UserFunctions.AdminFunctions();
								flag1 = 1;
								b = false;
							}
							break;
						default:
							System.out.println("Enter correct option!!");
							break;
						}
						break;
					} while (i == 1);
					break;

				case '2':
					int j = 0;
					do {
						System.out.println("1. REGISTER\n" + "2. LOGIN\n");
						System.out.println("Enter your choice : ");
						char ch3 = sc.next().charAt(0);
						switch (ch3) {
						case '1':

							UserFunctions.Details(2);
							j++;
						case '2':
							boolean fncs = true;
							while (fncs) {
								flag1 = 1;
								b = false;
								UserFunctions.CustomerFunctions();
							}
							break;
						default:
							System.out.println("Enter correct option!!");
							break;
						}
					} while (j == 1);
				default:
					System.out.println("Enter correct option!!");
					break;
				}
			}

		}

	}

}
