package com.cts.service;

import java.util.Random;

import java.util.Scanner;

import com.cts.DAO.DBOperations;
import com.cts.models.Admin;
import com.cts.models.Customer;
import com.cts.models.Products;

public class UserFunctions {
	static DBOperations op = new DBOperations();
	static boolean rs = op.Connect2DB();
	static Scanner sc = new Scanner(System.in);

	public static void CustomerFunctions() {
		System.out.println("1. READ ALL\n" + "2. SEARCH USING ID\n" + "3. SEARCH USING CATEGORY\n"
				+ "4. FILTER USING PRICE RANGE" + "5. EXIT");
		System.out.print("Enter your choice : ");
		char ch = sc.next().charAt(0);
		switch (ch) {
		case '1':
			System.out.println("READ ALL");
			if (rs) {
				boolean i = op.ReadAll();
				if (i) {
					System.out.println("------------- END OF THE LIST -------------");
				} else {
					System.out.println("PRODUCT COULDN'T BE READ");
				}
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '2':
			System.out.println("SEARCH USING ID");
			System.out.print("Enter the ID : ");
			String id1 = sc.next();
			if (rs) {
				op.SearchUsingID(id1);

				

			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '3':
			System.out.println("SEARCH USING CATEGORY");
			System.out.print("Enter the category : ");
			String cat = sc.next();
			if (rs) {
				boolean i = op.SearchUsingCat(cat);
				if (i) {
					System.out.println("------------- END OF THE LIST -------------");
				} else {
					System.out.println("PRODUCT COULDN'T BE READ");
				}
			}

			else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '4':
			System.out.println("FILTER USING PRICE RANGE");
			System.out.println("Enter price ranges : ");
			int price1 = sc.nextInt();
			int price2 = sc.nextInt();
			if (price1 < price2) {
				if (rs) {
					op.Filter(price1, price2);
				} else {
					System.out.println("CONNECTION FAILED");
				}
			} else {
				System.out.println("Price1 should be less than price2");
			}
			break;
		default:
			System.out.println("Enter the correct option!!");

		}
	}

	public static void AdminFunctions() {
		System.out.println("1. ADD A PRODUCT\n" + "2. UPDATE PRICE USING ID\n" + "3. DELETE\n" + "4. READ ALL\n"
				+ "5. SEARCH USING ID\n" + "6. SEARCH USING CATEGORY\n" + "7. EXIT");
		System.out.print("Enter your choice : ");
		char ch = sc.next().charAt(0);
		switch (ch) {
		case '1':
			System.out.println("ADD A PRODUCT");
			int ProdId = UserFunctions.RandomNumberGenerator();
			System.out.print("Enter the Product Name : \n");
			sc.nextLine();
			String ProdName = sc.nextLine();
			System.out.print("Enter the Product Description : \n");
			String ProdDesc = sc.next();
			System.out.print("Enter the Product Quantity : \n");
			int qty = sc.nextInt();
			System.out.print("Enter the price of the product : ");
			int price = sc.nextInt();
			new Products(ProdId, ProdName, ProdDesc, qty, price);
			if (rs) {
				boolean i = op.Insert2Table("PRODUCTS");
				if (i) {
					System.out.println("PRODUCT ADDED SUCCESSFULLY WITH PRODUCT ID : " + ProdId);
				} else {
					System.out.println("PRODUCT COULDN'T BE ADDED");
				}
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '2':
			System.out.println("UPDATE PRICE USING ID");
			System.out.print("Enter the Product Id : ");
			String id = sc.next();
			// ===========================================>
			System.out.print("Enter the Price : ");
			int amt = sc.nextInt();
			if (rs) {
				boolean i = op.UpdatePrice(id, amt);
				if (i) {
					System.out.println("PRODUCT UPDATED SUCCESSFULLY!!");
				} else {
					System.out.println("PRODUCT COULDN'T BE UPDATED");
				}
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '3':
			System.out.println("DELETE PRODUCT");
			System.out.print("Enter the product Id : ");
			String pid = sc.next();
			if (rs) {
				boolean i = op.DeleteProduct(pid);
				if (i) {
					System.out.println("PRODUCT DELETED SUCCESSFULLY!!");
				} else {
					System.out.println("PRODUCT COULDN'T BE DELETED");
				}
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '4':
			System.out.println("READ ALL");
			if (rs) {
				boolean i = op.ReadAll();
				if (i) {
					System.out.println("PRODUCT READ SUCCESSFULLY!!");
				} else {
					System.out.println("PRODUCT COULDN'T BE READ");
				}
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '5':
			System.out.println("SEARCH USING ID");
			System.out.print("Enter the ID : ");
			String id1 = sc.next();
			if (rs) {
				op.SearchUsingID(id1);
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '6':
			System.out.println("SEARCH USING CATEGORY");
			System.out.print("Enter the category : ");
			String cat = sc.next();
			if (rs) {
				op.SearchUsingCat(cat);
			} else {
				System.out.println("CONNECTION FAILED");
			}
			break;
		case '7':
			System.out.println("CLOSING CONNECTION!!!");
			System.exit(0);
		default:
			System.out.println("Enter the correct option!!");

		}
	}

	public static void Details(int val) {

		if (val == 1) {
			int AdminId = UserFunctions.RandomNumberGenerator();
			System.out.print("Enter Name : ");
			String name = Validations.validateName();
			System.out.print("Enter Gender : ");
			String gender = Validations.validateName();
			System.out.print("Enter Address : ");
			String address = sc.next();
			System.out.print("Enter Date of Birth : ");
			String dob = Validations.validateDateOfBirth();
			System.out.print("Enter UserName : ");
			String username = sc.next();
			boolean b = true;
			while (b) {
				System.out.print("Enter Password : ");
				String pass = sc.next();

				System.out.print("Re-Enter the Password : ");
				String pass1 = sc.next(); 

				boolean bo = Validations.passwordMisMatch(pass, pass1);
				if (bo) {
					new Admin(AdminId, name, gender, address, dob, username, pass);
					break;
				}
			}

			boolean rs = op.Insert2Table("ADMIN");
			if (rs) {
				System.out.println("ADMIN ADDED SUCCESFULLY");
				System.out.println("ADMIN ID : " + AdminId);
			} else {
				System.out.println("DETAILS COULD'NT BE ADDED ");
			}

		} else if (val == 2) {
			System.out.print("Enter Name : ");
			String name = Validations.validateName();
			System.out.print("Enter Gender : ");
			String gender = Validations.validateName();
			System.out.print("Enter Address : ");
			String address = sc.next();
			System.out.print("Enter Date of Birth : ");
			String dob = Validations.validateDateOfBirth();
			int CustId = UserFunctions.RandomNumberGenerator();
			System.out.print("Enter UserName : ");
			String username = sc.next();
			boolean b = true;
			while (b) {
				System.out.print("Enter Password : ");
				String pass = sc.next();

				System.out.print("Re-Enter the Password : ");
				String pass1 = sc.next();
				boolean bo = Validations.passwordMisMatch(pass, pass1);
				if (bo) {
					new Customer(CustId, username, gender, address, dob, username, pass);
					break;
				}
			}

			boolean rs = op.Insert2Table("CUSTOMER");
			if (rs) {
				System.out.println("CUSTOMER ADDED SUCCESFULLY");
				System.out.println("CUSOTMER ID : " + CustId);
			} else {
				System.out.println("DETAILS COULD'NT BE ADDED ");
			}
		}

	}

	public static int RandomNumberGenerator() {
		Random r = new Random();
		int num = r.nextInt(9000) + 1000;
		return num;
	}

}
