package com.cts.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validations {
	static Scanner sc = new Scanner(System.in);

	public static String validateName() {
		String name;
		boolean b = true;

		do {
			name = sc.next();
			if (name.matches("[a-zA-Z]*")) {
				b = false;
			} else {
				System.out.println("Enter your name only in Alphabets");
				System.out.print("Re-Enter the Name : ");
			}
		} while (b);
		return name;
	}

	public static String validateDateOfBirth() {
		String dobstr;
		boolean b = true;
		do {
			dobstr = sc.next();
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			df.setLenient(false);

			try {
				Date dob = df.parse(dobstr);
				b = false;
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Incorrect format!!");
				System.out.println("Enter the date in correct format (dd/MM/yyyy)");
			}
		} while (b);
		return dobstr;
	}

	public static boolean passwordMisMatch(String pass ,String pass1) {
		boolean b = true;
		
		while(b) {
			if(pass.equals(pass1)) {
				return true;
			}else {
				System.out.println("Passwords Doesn't Match!!");
				b =false;
				return false;
				
			}
		}
		return false;
	}

}
